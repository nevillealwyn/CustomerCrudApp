package com.neville.au.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.neville.au.model.Customer;
import com.neville.au.service.CustomerServiceImpl;

@RestController
public class custController {

	@Autowired
	private CustomerServiceImpl customerService;
	
	@GetMapping("/customer/")
	public List<Customer> getAllCustomers() {
		return customerService.getAllCustomers();
	}

	@GetMapping("/customer/{customerId}")
	public Customer getCustomerById(@PathVariable int customerId) {
		return customerService.getCustomerById(customerId);
	}
	
	@PostMapping("/customer/")
	public ResponseEntity<Void> addCustomer(@RequestBody Customer newCustomer, UriComponentsBuilder builder) {
		Customer customer = customerService.addCustomer(newCustomer);
		if (customer == null) {
			return ResponseEntity.noContent().build();
		}
		
		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(builder.path("/customer/{id}").buildAndExpand(customer.getId()).toUri());
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}
	
	@PutMapping("/customer/")
	public ResponseEntity<Customer> updateCustomer(@RequestBody Customer customer) {
		Customer custDetail = customerService.getCustomerById(customer.getId());
		
		if (custDetail == null) {
			return new ResponseEntity<Customer>(HttpStatus.NOT_FOUND);
		}
		custDetail.setName(customer.getName());
		custDetail.setTelephone(customer.getTelephone());
		customerService.updateCustomer(custDetail);
		return new ResponseEntity<Customer>(custDetail, HttpStatus.OK);
	}
	
	@DeleteMapping("/customer/{customerId}")
	public ResponseEntity<Customer> deleteCustomer(@PathVariable int customerId) {
		Customer customer = customerService.getCustomerById(customerId);
		
		if (customer == null) {
			return new ResponseEntity<Customer>(HttpStatus.NOT_FOUND);
		}
		customerService.deleteCustomer(customerId);
		return new ResponseEntity<Customer>(HttpStatus.OK);
	}
}
