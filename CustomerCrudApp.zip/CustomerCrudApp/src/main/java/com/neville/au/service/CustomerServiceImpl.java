package com.neville.au.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Component;

import com.neville.au.model.Customer;

@Component
public class CustomerServiceImpl implements CustomerService {

	private static List<Customer> customers = new ArrayList<>();
	
	static {
		Customer cust01 = new Customer(1, "Jack Sparrow", "12345678");
		Customer cust02 = new Customer(2, "Joe Blogs", "23456789");
		Customer cust03 = new Customer(3, "Mick Dynamo", "34567809");
		Customer cust04 = new Customer(4, "Donald Duck", "67890123");
		
		customers.add(cust01);
		customers.add(cust02);
		customers.add(cust03);
		customers.add(cust04);
	}
	
	@Override
	public List<Customer> getAllCustomers() {
		return customers;
	}

	@Override
	public Customer getCustomerById(int id) {
		for (Customer customer:customers) {
			if (customer.getId() == id) {
				return customer;
			}
		}
		return null;
	}

	@Override
	public Customer addCustomer(Customer customer) {
		Random random = new Random();
		int nextId = random.nextInt(1000) + 10;
		
		customer.setId(nextId);
		customers.add(customer);
		
		return customer;
	}

	@Override
	public void updateCustomer(Customer customer) {
		for (Customer oldCustomer:customers) {
			if (oldCustomer.getId() == customer.getId()) {
				oldCustomer.setName(customer.getName());
				oldCustomer.setTelephone(customer.getTelephone());
			}
		}
	}

	@Override
	public void deleteCustomer(int id) {
		for (Customer customer:customers) {
			if (customer.getId() == id) {
				customers.remove(customer);
			}
		}
	}

}
