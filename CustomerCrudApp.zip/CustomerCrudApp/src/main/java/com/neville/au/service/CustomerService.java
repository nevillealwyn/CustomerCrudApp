package com.neville.au.service;

import java.util.List;
import com.neville.au.model.*;

public interface CustomerService {

	public List<Customer> getAllCustomers();
	public Customer getCustomerById(int id);
	public Customer addCustomer(Customer customer);
	public void updateCustomer(Customer customer);
	public void deleteCustomer(int id);
	
}
